<template>
  <VCard>
    <VCardText class="py-16 mx-sm-16 px-md-9">
      <!-- 👉 App Pricing components -->
      <AppPricing
        md="4"
        cols="12"
      />
    </VCardText>
  </VCard>
</template>
