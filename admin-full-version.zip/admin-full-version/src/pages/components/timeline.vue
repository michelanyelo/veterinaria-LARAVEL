<template>
  <VRow>
    <VCol
      cols="12"
      md="6"
    >
      <TimelineBasic />
    </VCol>

    <VCol
      cols="12"
      md="6"
    >
      <TimelineOutlined />
    </VCol>

    <VCol cols="12">
      <TimelineWithIcons />
    </VCol>
  </VRow>
</template>
