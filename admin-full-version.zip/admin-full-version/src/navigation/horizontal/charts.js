export default [
  {
    title: 'Charts',
    icon: { icon: 'ri-bar-chart-2-line' },
    children: [
      { title: 'Apex Chart', to: 'charts-apex-chart', icon: { icon: 'ri-bar-chart-grouped-line' } },
      { title: 'Chartjs', to: 'charts-chartjs', icon: { icon: 'ri-line-chart-line' } },
    ],
  },
]
