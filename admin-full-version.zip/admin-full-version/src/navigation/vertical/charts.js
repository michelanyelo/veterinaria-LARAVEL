export default [
  { heading: 'Charts' },
  {
    title: 'Charts',
    icon: { icon: 'ri-bar-chart-2-line' },
    children: [
      { title: 'Apex Chart', to: 'charts-apex-chart' },
      { title: 'Chartjs', to: 'charts-chartjs' },
    ],
  },
]
